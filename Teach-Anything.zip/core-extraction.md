# Core-Extraction Worked Examples

The goal at Step 2 is always the same: find 4-6 concepts that, once really
understood, unlock most real competence — and are willing to explicitly cut
the long tail. Below are worked examples across three topic shapes.

## Technical / academic example: "Hypothesis testing for intro stats"

End state: pass an intro stats exam question and correctly reason about
whether a result is statistically meaningful.

Candidate core (kept):
1. Null vs. alternative hypothesis — what they actually claim
2. p-value — what it does and doesn't mean (the single most misunderstood idea)
3. Significance level / alpha and the decision rule
4. Type I vs. Type II errors — why both matter
5. One worked test end-to-end (e.g. one-sample t-test) tying it together

Cut or deferred: full derivations of test statistic formulas, non-parametric
test variants, multiple-comparison corrections. These matter for a stats
course eventually, but not for a 4-5 hour session aimed at "understand what a
hypothesis test is doing and use one."

## Conceptual example: "How the EU works"

End state: follow EU news intelligently and explain the basic power structure
to someone else.

Candidate core (kept):
1. The three main institutions (Commission, Parliament, Council) and what
   each actually does — most confusion comes from conflating these
2. How a law actually gets made (the basic legislative flow)
3. What's decided at EU level vs. still national (a genuinely load-bearing
   distinction people get wrong)
4. Why the Eurozone and Schengen aren't the same as "EU membership"

Cut or deferred: full history of EU treaties, minor agencies, detailed
budget mechanics. Interesting, but not needed for the stated end state.

## Practical/skill example: "How to negotiate a salary"

End state: walk into a real negotiation conversation and not freeze or
underprice themselves.

Candidate core (kept):
1. Anchoring — why and how to let the other side name a number first (or
   anchor high yourself if forced to go first)
2. Framing ask around market data / value, not personal need
3. Handling a lowball or "that's our final offer" response
4. What to actually say in the room — a few real scripts, practiced out loud

Cut or deferred: deep game theory of negotiation, negotiating equity/complex
comp structures, multi-party negotiation — over-scoped for someone prepping
for one conversation.

## Pattern to notice

In each case, the cut material isn't "less important in the abstract" — it's
"less load-bearing for THIS person's stated goal." Re-derive the core for
each person's actual end state rather than reusing a generic topic outline.
