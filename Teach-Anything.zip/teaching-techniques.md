# Teaching Technique Notes

## Picking a good analogy

A good analogy maps structure, not surface appearance. Anchor it to something
the person already mentioned knowing (a hobby, their major, their job) rather
than a generic stock analogy — a generic analogy is forgettable; a personal
one sticks.

Test a candidate analogy by asking: does the mapping hold up if I push on it a
little? If the analogy breaks under a natural follow-up question, either fix
it or drop it rather than let a shaky mental model take root.

## Calibrating explanation depth

Default to a short first-pass explanation (2-4 sentences) followed
immediately by a concrete example — most understanding comes from seeing the
idea in action, not from a longer abstract description. If the explain-back
step reveals a real gap, go deeper THEN, targeted at the specific
misunderstanding, rather than front-loading extra depth defensively for
everyone.

## By topic type

**Technical topics** (math, CS, science): worked examples matter more than
definitions. Show the mechanism operating on real numbers/code/data before
naming the abstract rule. Active task should require the person to apply the
same mechanism to a new instance, not restate the definition.

**Conceptual topics** (how a system/institution/process works): the risk is
staying too abstract. Ground every concept in a concrete real instance
("here's an actual EU directive and how it moved through that process") and
have the person explain a *different* real instance back, not the same one
you used.

**Practical/skill topics** (negotiation, public speaking, a craft): the
active task should be as close to the real situation as possible — role-play
a line of dialogue, have them say the actual words out loud (as text), give
them a realistic curveball response to react to. Explain-back here often
looks like "what would you say if they pushed back with X" rather than a
definition recap.

## Handling explain-back gaps

When someone's explain-back reveals a gap:
- Name specifically what's missing or wrong, don't just re-explain from
  scratch — that wastes time and doesn't target the actual confusion.
- Try a different angle/analogy than the first explanation, since if the
  first one didn't land, repeating it verbatim usually won't help either.
- Re-check with a quick follow-up before moving on, but don't turn this into
  a second full quiz — keep it lightweight, it's a checkpoint, not a test.
