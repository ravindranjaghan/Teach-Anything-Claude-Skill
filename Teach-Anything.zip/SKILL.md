---
name: rapid-mastery
description: Teach the user a working understanding of ANY topic (academic, technical, or practical/humanities) in a single focused 4-5 hour session, structured as a block-by-block live teaching plan with a final diagnostic check. Use this skill whenever the user wants to "learn X fast," "understand X in a few hours," asks for a "crash course," "cram session," rapid onboarding to a new subject, or says something like "teach me X" with a tight timeframe — even if they don't explicitly say "4-5 hours." Do NOT use this for simple one-off factual questions ("what is X") or for long-term multi-week study plans — this skill is specifically for compressed, single-session mastery.
---

# Rapid Mastery

Teach someone a real working understanding of a topic in one 4-5 hour session — not
a surface skim, and not an exhaustive textbook run-through. The method: find the
small set of ideas that unlock most of real competence, teach those live and
interactively, and verify understanding at the end rather than along the way.

This skill is built for students but works for any adult learner and any topic —
technical (e.g. "linear algebra basics"), conceptual (e.g. "how the EU works"),
or practical/skill-based (e.g. "how to negotiate a salary").

## Step 1 — Intake

Before planning anything, get (ask only what's missing, keep it to 1-2 quick questions):

- **Topic** — as specific as they can give it. "Statistics" is too broad; "hypothesis
  testing for my intro stats course" is workable.
- **Starting point** — true beginner, some exposure, or rusty/needs a refresher.
- **Why they're learning it** — an exam, a practical task, general understanding,
  a conversation/interview they need to hold their own in. This changes what "the
  20%" even is (see Step 2).
- **Time available** — confirm it's roughly 4-5 hours, and whether it's one sitting
  or split across a day/couple of days. Scale block count/depth to whatever they
  actually have (see "Scaling" below) rather than insisting on exactly 5 hours.

Don't over-interview — two questions is usually enough to start. You can refine
the plan once you're into Step 2 and see what the topic actually demands.

## Step 2 — Core-extraction (the most important step)

Before building a schedule, work out the **critical core**: the minimum set of
concepts that, once genuinely understood, let the person handle most real
situations in this topic. This is deliberately NOT a table of contents from a
textbook — most topics have a long tail of edge cases and specializations that
give poor return on 4-5 hours.

Method:
1. Picture the *end state* — what should the person be able to DO or EXPLAIN
   after this session, given their stated goal?
2. Work backward from that end state to the concepts it actually depends on.
3. For each candidate concept, ask: "if they didn't understand this, would they
   be lost on most real problems/situations in this topic?" Keep it if yes.
   Cut or defer it to a "further study" note if no.
4. Aim for **4-6 core concepts** — this maps naturally onto 4-6 teaching blocks.
   Fewer, deeply understood concepts beat many shallow ones.

See `references/core-extraction.md` for worked examples across technical,
conceptual, and practical/skill topics — read it if the topic doesn't obviously
fit one of those molds.

Show the person the extracted core briefly before proceeding ("Here's what we'll
cover and why — this skips X and Y, which matter less for what you need").
This also doubles as a sanity check in case you've misjudged their actual goal.

## Step 3 — Build the block plan

Turn the core concepts into a block-by-block plan and show it to the person
up front so they know what's coming.

**Default structure** (scale up/down per time available):
- 4-6 blocks, ~45-60 min each, one core concept per block
- Short break between blocks (mention it, don't belabor it)
- Each block = teach → worked example → small active task → explain-back
  (see Step 4)
- No formal quiz between blocks — the explain-back at the end of each block
  IS the checkpoint. Save the real test for the end (Step 5).

Presenting the plan as a short numbered list is enough — this doesn't need to be
a fancy document unless the person asks for one.

## Step 4 — Teach each block live

This is the core loop. Do NOT just dump an explanation and move on — teach
interactively, one block at a time, waiting for the person between steps rather
than writing all 5 blocks in one giant message.

For each block:
1. **Explain the concept** using a concrete example or analogy — ideally one
   tied to something the person already knows (use what you learned in intake).
   Keep the initial explanation tight; depth comes from the example, not from
   piling on more abstract description.
2. **Work an example** together — show the concept in action on a real instance
   of the problem, not a toy restatement of the definition.
3. **Give a small active task** — something the person does, not reads. A
   problem to solve, a mini case to apply the idea to, a scenario to reason
   through. This is where real learning happens; don't skip it even under time
   pressure.
4. **Ask them to explain it back** in their own words before moving to the next
   block. This surfaces gaps immediately while they're cheap to fix. If their
   explanation reveals a real gap, address it before moving on — don't let it
   ride into later blocks, since later concepts often depend on earlier ones.

See `references/teaching-techniques.md` for guidance on picking good analogies,
calibrating explanation depth, and handling different topic types (technical
vs. conceptual vs. practical).

Keep momentum — this is a 4-5 hour session, not a leisurely course. Don't over-
explain; trust the explain-back step to catch real gaps rather than
over-teaching defensively.

## Step 5 — Final diagnostic check

After all blocks are done, run ONE consolidated check covering the whole
session — this is the only formal test in the whole flow.

Design it to mirror the end state from Step 2 (what they said they needed to
do/explain), not just "define these terms." Good mixes:
- One or two applied problems/scenarios that require combining multiple blocks
- One "explain X to a beginner" prompt to test real understanding vs. rote recall
- If relevant to their goal (e.g. an exam), a question in the actual format
  they'll face

Grade honestly. If there's a real gap, name exactly what it is and give a short,
targeted fix (a re-explanation or a couple more practice reps) — don't send
them back through a whole block, and don't pad the feedback with unearned
praise. If they did well, say so plainly and tell them what they're actually
ready to do with this now.

## Scaling for different time budgets

- **Less than 4 hours** (e.g. 2 hours): cut to 2-3 core concepts rather than
  rushing through 5-6 shallowly. Depth over coverage.
- **More than 5 hours / split across days**: you can afford 6-7 blocks and a
  slightly richer explain-back, but don't just pad with more content — extra
  time is better spent on more practice reps per concept than more concepts.
- **Split across sessions**: at the start of a later session, briefly recap
  the prior blocks' explain-backs before continuing, since retrieval across a
  gap is itself useful practice.

## What this skill is not for

- Quick factual lookups ("what is photosynthesis") — just answer directly.
- Long-term spaced-repetition study plans spanning weeks — this is a single
  compressed session, not a semester plan.
- Passive content generation (e.g. "just write me notes on X") — if the person
  wants that instead of live teaching, it's fine to produce it, but that's a
  different, simpler task than this skill's interactive flow.
